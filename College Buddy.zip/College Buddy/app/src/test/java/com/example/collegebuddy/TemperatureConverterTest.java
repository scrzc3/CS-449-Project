package com.example.collegebuddy;
//Created by Sam Rovenstine Spring 2019

import org.junit.Test;

public class TemperatureConverterTest {


    @Test
    public void fahrenheit_to_celsius() throws Exception {

    }

    @Test
    public void celsius_to_fahrenheit() throws Exception {

    }

}
