package com.example.collegebuddy;
//Created by Sam Rovenstine Spring 2019


import android.content.Intent;
import android.graphics.Color;
import android.provider.Settings;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;
import com.hitomi.cmlibrary.CircleMenu;
import com.hitomi.cmlibrary.OnMenuSelectedListener;
import com.hitomi.cmlibrary.OnMenuStatusChangeListener;

public class MainActivity extends AppCompatActivity {

    CircleMenu circleMenu;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button easterEgg;

        circleMenu = findViewById(R.id.circleMenu);

        circleMenu.setMainMenu(Color.parseColor("#CDCDCD"), R.drawable. add, R.drawable.remove)
                .addSubMenu(Color.parseColor("#258CFF"), R.drawable.ic_kitchen)
                .addSubMenu(Color.parseColor("#30A400"), R.drawable.ic_party)
                .addSubMenu(Color.parseColor("#FF4B32"), R.drawable.ic_study)
                .addSubMenu(Color.parseColor("#8A39FF"), R.drawable.ic_help)
                .addSubMenu(Color.parseColor("#FF6A00"), R.drawable.ic_settings)
                .setOnMenuSelectedListener(new OnMenuSelectedListener() {
                    @Override
                    public void onMenuSelected(int index) {
                        switch (index) {
                            case 0:
                                //Toast.makeText(MainActivity.this, "Kitchen Buddy",Toast.LENGTH_SHORT).show();
                                Intent kitchen = new Intent(MainActivity.this, KitchenActivity.class);
                                startActivity(kitchen);
                                break;
                            case 1:
                                //Toast.makeText(MainActivity.this,"Party Buddy",Toast.LENGTH_SHORT).show();
                                Intent party = new Intent(MainActivity.this, PartyActivity.class);
                                startActivity(party);
                                break;
                            case 2:
                                //Toast.makeText(MainActivity.this,"Study Buddy",Toast.LENGTH_SHORT).show();
                                Intent study = new Intent(MainActivity.this, StudyActivity.class);
                                startActivity(study);
                                break;
                            case 3:
                                //Toast.makeText(MainActivity.this,"Help",Toast.LENGTH_SHORT).show();
                                Intent help = new Intent(MainActivity.this, HelpActivity.class);
                                startActivity(help);
                                break;
                            case 4:
                                //Toast.makeText(MainActivity.this,"Settings",Toast.LENGTH_SHORT).show();
                                Intent settings = new Intent(MainActivity.this, SettingsActivity.class);
                                startActivity(settings);
                                break;
                        }

                    }

                });

        easterEgg = findViewById(R.id.easteregg);
        easterEgg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, EasterEggActivity.class));
            }
        });
    }
}

