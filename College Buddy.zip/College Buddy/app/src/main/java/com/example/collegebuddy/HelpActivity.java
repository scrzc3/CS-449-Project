package com.example.collegebuddy;
//Created by Sam Rovenstine Spring 2019

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import com.ms.square.android.expandabletextview.ExpandableTextView;

public class HelpActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_help);

        ExpandableTextView view1 = findViewById(R.id.expand_text_view);
        view1.setText(getString(R.string.Activities_Kitchen_Description));

        ExpandableTextView view2 = findViewById(R.id.expand_text_view_2);
        view2.setText(getString(R.string.Activities_Party_Description));

        ExpandableTextView view3 = findViewById(R.id.expand_text_view_3);
        view3.setText(getString(R.string.Activities_Study_Description));

        ExpandableTextView view4 = findViewById(R.id.expand_text_view_4);
        view4.setText(getString(R.string.Activities_Settings_Description));

    }
}