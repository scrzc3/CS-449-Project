package com.example.collegebuddy;
//Created by Sam Rovenstine Spring 2019

import android.media.MediaPlayer;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;

public class SoundBoardActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_soundboard);

        final MediaPlayer yodelBoyMP = MediaPlayer.create(this, R.raw.yodel_boy);
        Button playYodelBoy = this.findViewById(R.id.button);
        playYodelBoy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (yodelBoyMP.isPlaying()){
                    yodelBoyMP.pause();
                }
                else {
                    yodelBoyMP.start();
                }
            }

        });

        final MediaPlayer yeetMP = MediaPlayer.create(this, R.raw.yeet);
        Button playYeet = this.findViewById(R.id.button2);
        playYeet.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (yeetMP.isPlaying()){
                    yeetMP.pause();
                }
                else {
                    yeetMP.start();
                }
            }
        });

        final MediaPlayer imOutMP = MediaPlayer.create(this, R.raw.f_this_shit_im_out);
        Button playImOut = this.findViewById(R.id.button3);
        playImOut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (imOutMP.isPlaying()){
                    imOutMP.pause();
                }
                else {
                    imOutMP.start();
                }
            }
        });

        final MediaPlayer wednesdayMP = MediaPlayer.create(this, R.raw.wednesday);
        Button playWednesday = this.findViewById(R.id.button4);
        playWednesday.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (wednesdayMP.isPlaying()){
                    wednesdayMP.pause();
                }
                else {
                    wednesdayMP.start();
                }
            }
        });

        final MediaPlayer johnCenaMP = MediaPlayer.create(this, R.raw.john_cena);
        Button playJohnCena = this.findViewById(R.id.button5);
        playJohnCena.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (johnCenaMP.isPlaying()){
                    johnCenaMP.pause();
                }
                else {
                    johnCenaMP.start();
                }
            }
        });

        final MediaPlayer damnDanielMP = MediaPlayer.create(this, R.raw.damn_daniel);
        Button playdamnDaniel = this.findViewById(R.id.button6);
        playdamnDaniel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (damnDanielMP.isPlaying()){
                    damnDanielMP.pause();
                }
                else {
                    damnDanielMP.start();
                }
            }
        });
    }


}
