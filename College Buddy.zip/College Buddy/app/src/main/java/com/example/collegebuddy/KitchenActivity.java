package com.example.collegebuddy;
//Created by Sam Rovenstine Spring 2019

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import java.math.BigDecimal;
import java.math.RoundingMode;


public class KitchenActivity  extends AppCompatActivity implements AdapterView.OnItemSelectedListener{

    //algorithm for rounding values in conversion process
    public static double Round(double value, int places) {
        if (places < 0) throw new IllegalArgumentException();

        BigDecimal bd = new BigDecimal(value);
        bd = bd.setScale(places, RoundingMode.HALF_UP);
        return bd.doubleValue();
    }

    //starting boolean values before user inputs number to be calculated
    boolean
    starting_tsp = false,
    starting_tbsp = false,
    starting_oz = false,
    starting_cup = false,
    starting_lbs = false,
    starting_pint = false,
    starting_quart = false,
    starting_gallon = false,

    //calculated boolean values
    converted_tsp = false,
    converted_tbsp = false,
    converted_oz = false,
    converted_cup = false,
    converted_lbs = false,
    converted_pint = false,
    converted_quart = false,
    converted_gallon = false;

    //conversion button
    Button mConvert;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_kitchen);

        //spinner setup
        Spinner starting_weight_spin = findViewById(R.id.starting_value_spinner);
        Spinner conversion_weight_spin = findViewById(R.id.converted_value_spinner);

        //array adapter using spinner and string array
        ArrayAdapter<CharSequence> starting_adapter = ArrayAdapter.createFromResource(this,
                R.array.measurement_units, android.R.layout.simple_spinner_dropdown_item);
        ArrayAdapter<CharSequence> conversion_adapter = ArrayAdapter.createFromResource(this,
                R.array.measurement_units, android.R.layout.simple_spinner_dropdown_item);


        //layouts
        starting_adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        conversion_adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        //adapter is applied here
        starting_weight_spin.setAdapter(starting_adapter);
        starting_weight_spin.setOnItemSelectedListener(this);
        conversion_weight_spin.setAdapter(conversion_adapter);
        conversion_weight_spin.setOnItemSelectedListener(this);


        mConvert = findViewById(R.id.convert_button);

        mConvert.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                double input_Value, converted_Value;
                EditText starting_string = findViewById(R.id.starting_value_text);
                TextView conversion_view = findViewById(R.id.conversion_view);

                try {
                    input_Value = Double.parseDouble(starting_string.getText().toString());
                    converted_Value = converter_wrapper(input_Value);
                    conversion_view.setText(String.valueOf(Round(converted_Value, 2)));
                }
                catch (NumberFormatException exception) {
                    conversion_view.setText(String.valueOf(0));
                }
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_kitchen, menu);
        return super.onCreateOptionsMenu(menu);
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        Intent intent;
        switch (item.getItemId()) {
            case R.id.safe_temps:
                intent = new Intent(this, SafeTempsActivity.class);
                startActivity(intent);
                return true;
            case R.id.temperature_converter:
                intent = new Intent(this, TemperatureActivity.class);
                startActivity(intent);
                return true;
            default:
                return super.onOptionsItemSelected(item);

        }
    }


    //an item is selected by user, parent.getItemAtPosition(pos) retreives said item
    public void onItemSelected(AdapterView<?> parent, View view, int pos, long id) {

        switch (parent.getId()) {
            case R.id.starting_value_spinner:
                switch (pos) {
                    case 0:
                        reset_bools("start");
                        starting_tsp = true;
                        break;
                    case 1:
                        reset_bools("start");
                        starting_tbsp = true;
                        break;
                    case 2:
                        reset_bools("start");
                        starting_oz = true;
                        break;
                    case 3:
                        reset_bools("start");
                        starting_lbs = true;
                        break;
                    case 4:
                        reset_bools("start");
                        starting_cup = true;
                        break;
                    case 5:
                        reset_bools("start");
                        starting_pint = true;
                        break;
                    case 6:
                        reset_bools("start");
                        starting_quart = true;
                        break;
                    case 7:
                        reset_bools("start");
                        starting_gallon = true;
                        break;
                    default:
                        break;
                }
                break;

            case R.id.converted_value_spinner:
                switch (pos) {
                    case 0:
                        reset_bools("result");
                        converted_tsp = true;
                        break;
                    case 1:
                        reset_bools("result");
                        converted_tbsp = true;
                        break;
                    case 2:
                        reset_bools("result");
                        converted_oz = true;
                        break;
                    case 3:
                        reset_bools("result");
                        converted_lbs = true;
                        break;
                    case 4:
                        reset_bools("result");
                        converted_cup = true;
                        break;
                    case 5:
                        reset_bools("result");
                        converted_pint = true;
                        break;
                    case 6:
                        reset_bools("result");
                        converted_quart = true;
                        break;
                    case 7:
                        reset_bools("result");
                        converted_gallon = true;
                        break;
                    default:
                        break;
                }
        }
    }

    public void onNothingSelected(AdapterView<?> parent) {
    }

    //resets starting and ending boolean spinner values to false
    private void reset_bools(String starting_result){

        if (starting_result == "start") {
            starting_tsp = false;
            starting_tbsp = false;
            starting_oz = false;
            starting_cup = false;
            starting_lbs = false;
            starting_pint = false;
            starting_quart = false;
            starting_gallon = false;
        }
        else if (starting_result == "result") {
            converted_tsp = false;
            converted_tbsp = false;
            converted_oz = false;
            converted_cup = false;
            converted_lbs = false;
            converted_pint = false;
            converted_quart = false;
            converted_gallon = false;
        }
    }

    private double converter_wrapper(double inputValue) {
        boolean[] starting_bools = grab_starting_bools(), converted_bools = grab_converted_bools();
        int i = 0, starting_bool_loc = 0, converted_bool_loc = 0;
        while(i < 8){
            if (starting_bools[i]){
                starting_bool_loc = i;
            }
            if (converted_bools[i]){
                converted_bool_loc = i;
            }
            i = i + 1;
        }
        return conversionSwitchCase(starting_bool_loc, converted_bool_loc, inputValue);
    }

    private boolean[] grab_starting_bools() {
        boolean[] starting_bools = new boolean[8];
        starting_bools[0] = starting_tsp;
        starting_bools[1] = starting_tbsp;
        starting_bools[2] = starting_oz;
        starting_bools[3] = starting_lbs;
        starting_bools[4] = starting_cup;
        starting_bools[5] = starting_pint;
        starting_bools[6] = starting_quart;
        starting_bools[7] = starting_gallon;

        return starting_bools;
    }

    private boolean[] grab_converted_bools(){
        boolean[] converted_bools = new boolean[8];
        converted_bools[0] =  converted_tsp;
        converted_bools[1] =  converted_tbsp;
        converted_bools[2] =  converted_oz;
        converted_bools[3] =  converted_lbs;
        converted_bools[4] =  converted_cup;
        converted_bools[5] =  converted_pint;
        converted_bools[6] =  converted_quart;
        converted_bools[7] =  converted_gallon;

        return converted_bools;
    }


    //for catching starting and ending conversions
    public double conversionSwitchCase(int start_loc, int result_loc, double startVal) {
        double convertedVal = -1;

        switch (start_loc) {
            case 0:
                switch (result_loc) {
                    case 0:
                        convertedVal = MeasurementConverter.tsp_To_tsp(startVal);
                        break;
                    case 1:
                        convertedVal = MeasurementConverter.tsp_To_tbsp(startVal);
                        break;
                    case 2:
                        convertedVal = MeasurementConverter.tsp_To_oz(startVal);
                        break;
                    case 3:
                        convertedVal = MeasurementConverter.tsp_To_lbs(startVal);
                        break;
                    case 4:
                        convertedVal = MeasurementConverter.tsp_To_cup(startVal);
                        break;
                    case 5:
                        convertedVal = MeasurementConverter.tsp_To_pint(startVal);
                        break;
                    case 6:
                        convertedVal = MeasurementConverter.tsp_To_quart(startVal);
                        break;
                    case 7:
                        convertedVal = MeasurementConverter.tsp_To_gallon(startVal);
                        break;
                    default:
                        break;
                }
                break;

            case 1:
                switch (result_loc){
                    case 0:
                        convertedVal = MeasurementConverter.tbsp_To_tsp(startVal);
                        break;
                    case 1:
                        convertedVal = MeasurementConverter.tbsp_To_tbsp(startVal);
                        break;
                    case 2:
                        convertedVal = MeasurementConverter.tbsp_To_oz(startVal);
                        break;
                    case 3:
                        convertedVal = MeasurementConverter.tbsp_To_lbs(startVal);
                        break;
                    case 4:
                        convertedVal = MeasurementConverter.tbsp_To_cup(startVal);
                        break;
                    case 5:
                        convertedVal = MeasurementConverter.tbsp_To_pint(startVal);
                        break;
                    case 6:
                        convertedVal = MeasurementConverter.tbsp_To_quart(startVal);
                        break;
                    case 7:
                        convertedVal = MeasurementConverter.tbsp_To_gallon(startVal);
                        break;
                    default:
                        break;
                }
                break;
            case 2:
                switch (result_loc) {
                    case 0:
                        convertedVal = MeasurementConverter.oz_To_tsp(startVal);
                        break;
                    case 1:
                        convertedVal = MeasurementConverter.oz_To_tbsp(startVal);
                        break;
                    case 2:
                        convertedVal = MeasurementConverter.oz_To_oz(startVal);
                        break;
                    case 3:
                        convertedVal = MeasurementConverter.oz_To_lbs(startVal);
                        break;
                    case 4:
                        convertedVal = MeasurementConverter.oz_To_cup(startVal);
                        break;
                    case 5:
                        convertedVal = MeasurementConverter.oz_To_pint(startVal);
                        break;
                    case 6:
                        convertedVal = MeasurementConverter.oz_To_quart(startVal);
                        break;
                    case 7:
                        convertedVal = MeasurementConverter.oz_To_gallon(startVal);
                        break;
                    default:
                        break;
                }
                break;
            case 3:
                switch (result_loc) {
                    case 0:
                        convertedVal = MeasurementConverter.lbs_To_tsp(startVal);
                        break;
                    case 1:
                        convertedVal = MeasurementConverter.lbs_To_tbsp(startVal);
                        break;
                    case 2:
                        convertedVal = MeasurementConverter.lbs_To_oz(startVal);
                        break;
                    case 3:
                        convertedVal = MeasurementConverter.lbs_To_lbs(startVal);
                        break;
                    case 4:
                        convertedVal = MeasurementConverter.lbs_To_cup(startVal);
                        break;
                    case 5:
                        convertedVal = MeasurementConverter.lbs_To_pint(startVal);
                        break;
                    case 6:
                        convertedVal = MeasurementConverter.lbs_To_quart(startVal);
                        break;
                    case 7:
                        convertedVal = MeasurementConverter.lbs_To_gallon(startVal);
                        break;
                    default:
                        break;
                }
                break;
            case 4:
                switch (result_loc) {
                    case 0:
                        convertedVal = MeasurementConverter.cup_To_tsp(startVal);
                        break;
                    case 1:
                        convertedVal = MeasurementConverter.cup_To_tbsp(startVal);
                        break;
                    case 2:
                        convertedVal = MeasurementConverter.cup_To_oz(startVal);
                        break;
                    case 3:
                        convertedVal = MeasurementConverter.cup_To_lbs(startVal);
                        break;
                    case 4:
                        convertedVal = MeasurementConverter.cup_To_cup(startVal);
                        break;
                    case 5:
                        convertedVal = MeasurementConverter.cup_To_pint(startVal);
                        break;
                    case 6:
                        convertedVal = MeasurementConverter.cup_To_quart(startVal);
                        break;
                    case 7:
                        convertedVal = MeasurementConverter.cup_To_gallon(startVal);
                        break;
                    default:
                        break;
                }
                break;
            case 5:
                switch (result_loc) {
                    case 0:
                        convertedVal = MeasurementConverter.pint_To_tsp(startVal);
                        break;
                    case 1:
                        convertedVal = MeasurementConverter.pint_To_tbsp(startVal);
                        break;
                    case 2:
                        convertedVal = MeasurementConverter.pint_To_oz(startVal);
                        break;
                    case 3:
                        convertedVal = MeasurementConverter.pint_To_lbs(startVal);
                        break;
                    case 4:
                        convertedVal = MeasurementConverter.pint_To_cup(startVal);
                        break;
                    case 5:
                        convertedVal = MeasurementConverter.pint_To_pint(startVal);
                        break;
                    case 6:
                        convertedVal = MeasurementConverter.pint_To_quart(startVal);
                        break;
                    case 7:
                        convertedVal = MeasurementConverter.pint_To_gallon(startVal);
                        break;
                    default:
                        break;
                }
                break;
            case 6:
                switch (result_loc) {
                    case 0:
                        convertedVal = MeasurementConverter.quart_To_tsp(startVal);
                        break;
                    case 1:
                        convertedVal = MeasurementConverter.quart_To_tbsp(startVal);
                        break;
                    case 2:
                        convertedVal = MeasurementConverter.quart_To_oz(startVal);
                        break;
                    case 3:
                        convertedVal = MeasurementConverter.quart_To_lbs(startVal);
                        break;
                    case 4:
                        convertedVal = MeasurementConverter.quart_To_cup(startVal);
                        break;
                    case 5:
                        convertedVal = MeasurementConverter.quart_To_pint(startVal);
                        break;
                    case 6:
                        convertedVal = MeasurementConverter.quart_To_quart(startVal);
                        break;
                    case 7:
                        convertedVal = MeasurementConverter.quart_To_gallon(startVal);
                        break;
                    default:
                        break;
                }
                break;
            case 7:
                switch (result_loc) {
                    case 0:
                        convertedVal = MeasurementConverter.gallon_To_tsp(startVal);
                        break;
                    case 1:
                        convertedVal = MeasurementConverter.gallon_To_tbsp(startVal);
                        break;
                    case 2:
                        convertedVal = MeasurementConverter.gallon_To_oz(startVal);
                        break;
                    case 3:
                        convertedVal = MeasurementConverter.gallon_To_lbs(startVal);
                        break;
                    case 4:
                        convertedVal = MeasurementConverter.gallon_To_cup(startVal);
                        break;
                    case 5:
                        convertedVal = MeasurementConverter.gallon_To_pint(startVal);
                        break;
                    case 6:
                        convertedVal = MeasurementConverter.gallon_To_quart(startVal);
                        break;
                    case 7:
                        convertedVal = MeasurementConverter.gallon_To_gallon(startVal);
                        break;
                    default:
                        break;
                }
                break;
            default:
                break;
        }
        return convertedVal;
    }
}
