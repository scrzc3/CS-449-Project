package com.example.collegebuddy;
//Created by Sam Rovenstine Spring 2019

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import com.ms.square.android.expandabletextview.ExpandableTextView;

public class BreakfastActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_breakfast);

        ExpandableTextView view1 = findViewById(R.id.expand_text_view_5);
        view1.setText(getString(R.string.Activities_Breakfast1));

        ExpandableTextView view2 = findViewById(R.id.expand_text_view_6);
        view2.setText(getString(R.string.Activities_Breakfast2));

    }
}
