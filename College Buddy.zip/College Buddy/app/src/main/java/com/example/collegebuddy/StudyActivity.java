package com.example.collegebuddy;
//Created by Sam Rovenstine Spring 2019

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import java.util.Scanner;
import com.example.collegebuddy.Notes.NotesActivity;
import com.example.collegebuddy.Schedule.AssignmentScheduleActivity;

public class StudyActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_study);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_study, menu);
        return super.onCreateOptionsMenu(menu);
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        Intent intent;
        switch (item.getItemId()) {
            case R.id.note_cards:
                intent = new Intent(this, NoteCardsActivity.class);
                startActivity(intent);
                return true;
            case R.id.notes:
                intent = new Intent(this, NotesActivity.class);
                startActivity(intent);
                return true;
            case R.id.gpa:
                intent = new Intent(this, GPACalculatorActivity.class);
                startActivity(intent);
                return true;
            case R.id.schedule:
                intent = new Intent(this, AssignmentScheduleActivity.class);
                startActivity(intent);
                return true;
            default:
                return super.onOptionsItemSelected(item);

        }
    }
}

