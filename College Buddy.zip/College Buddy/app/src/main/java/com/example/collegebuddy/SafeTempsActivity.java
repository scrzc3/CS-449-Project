package com.example.collegebuddy;
//Created by Sam Rovenstine Spring 2019

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

public class SafeTempsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_safe_temps);
    }
}
