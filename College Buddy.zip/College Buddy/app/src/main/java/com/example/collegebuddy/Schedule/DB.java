package com.example.collegebuddy.Schedule;
//Created by Sam Rovenstine Spring 2019

public class DB {
    public static final String TABLE_NAME = "schedules";
}
