package com.example.collegebuddy;
//Created by Sam Rovenstine Spring 2019

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.CardView;
import android.view.View;
import android.widget.GridLayout;

public class RecipesActivity extends AppCompatActivity {

    GridLayout mainGrid;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recipes);

        mainGrid = (GridLayout)findViewById(R.id.mainGrid);

        setSingleEvent(mainGrid);
    }

    private void setSingleEvent (GridLayout mainGrid) {

        for (int i = 0; i < mainGrid.getChildCount(); i++){
            CardView cardView = (CardView) mainGrid.getChildAt(i);
            final int finalI = i;
            cardView.setOnClickListener(new View.OnClickListener() {

                @Override
                public void onClick(View v) {

                    if(finalI == 0){ //breakfast activity opens
                        Intent intent = new Intent(RecipesActivity.this, BreakfastActivity.class);
                        startActivity(intent);
                    }
                    else if(finalI == 1){ //lunch activity opens
                        Intent intent = new Intent(RecipesActivity.this, LunchActivity.class);
                        startActivity(intent);
                    }
                    else if(finalI == 2){ //dinner activity opens
                        Intent intent = new Intent(RecipesActivity.this, DinnerActivity.class);
                        startActivity(intent);
                    }
                    else if(finalI == 3){ //drinks activity opens
                        Intent intent = new Intent(RecipesActivity.this, DrinksActivity.class);
                        startActivity(intent);
                    }
                    else if(finalI == 4){ //hangover cures activity opens
                        Intent intent = new Intent(RecipesActivity.this, HangoverCuresActivity.class);
                        startActivity(intent);
                    }
                    else if(finalI == 5){ //snacks activity opens
                        Intent intent = new Intent(RecipesActivity.this, SnacksActivity.class);
                        startActivity(intent);
                    }
                }
            });
        }
    }
}
