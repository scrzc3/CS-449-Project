package com.example.collegebuddy;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import com.ms.square.android.expandabletextview.ExpandableTextView;

public class LunchActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lunch);

        ExpandableTextView view1 = findViewById(R.id.expand_text_view_7);
        view1.setText(getString(R.string.Activities_Lunch1));

        ExpandableTextView view2 = findViewById(R.id.expand_text_view_8);
        view2.setText(getString(R.string.Activities_Lunch2));
    }
}
