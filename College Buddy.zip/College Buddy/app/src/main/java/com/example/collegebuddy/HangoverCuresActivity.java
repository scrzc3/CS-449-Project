package com.example.collegebuddy;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import com.ms.square.android.expandabletextview.ExpandableTextView;

public class HangoverCuresActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hangover_cures);

        ExpandableTextView view1 = findViewById(R.id.expand_text_view_15);
        view1.setText(getString(R.string.Activities_Hangover1));

        ExpandableTextView view2 = findViewById(R.id.expand_text_view_16);
        view2.setText(getString(R.string.Activities_Hangover2));
    }
}
