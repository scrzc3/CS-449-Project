package com.example.collegebuddy;
//Created by Sam Rovenstine Spring 2019


import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.SpannableString;
import android.text.style.UnderlineSpan;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import java.math.BigDecimal;
import java.math.RoundingMode;

public class TemperatureActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener {

    boolean starting_temperature = false;
    boolean result_temperature = false;

    //rounding formula used in the the measurement converter
    public static double Round(double value, int places) {
        if (places < 0) throw new IllegalArgumentException();

        BigDecimal bd = new BigDecimal(value);
        bd = bd.setScale(places, RoundingMode.HALF_UP);
        return bd.doubleValue();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_temperature);

        //setting starting spinners
        Spinner temp_starting_spinner = findViewById(R.id.temp_starting_spinner);
        Spinner temp_result_spinner = findViewById(R.id.temp_result_spinner);

        //ArrayAdapter
        ArrayAdapter<CharSequence> start_temp_adapter = ArrayAdapter.createFromResource(this,
                R.array.temp_units, android.R.layout.simple_spinner_dropdown_item);
        ArrayAdapter<CharSequence> result_temp_adapter = ArrayAdapter.createFromResource(this,
                R.array.temp_units, android.R.layout.simple_spinner_dropdown_item);

        //layout
        start_temp_adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        result_temp_adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        //adapter application
        temp_starting_spinner.setAdapter(start_temp_adapter);
        temp_starting_spinner.setOnItemSelectedListener(this);
        temp_result_spinner.setAdapter(result_temp_adapter);
        temp_result_spinner.setOnItemSelectedListener(this);

        //linking result view
        TextView result_textView = findViewById(R.id.temp_result_val);
        SpannableString new_result = new SpannableString("Result Value");
        new_result.setSpan(new UnderlineSpan(),0, new_result.length(), 0);
        result_textView.setText(new_result);

        //linking button
        Button mTemperatureConvertButton = findViewById(R.id.temp_convert_button);

        mTemperatureConvertButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                double input_Val = 0.0, converted_val;
                int choice;
                EditText start_string = findViewById(R.id.temp_starting_val);
                TextView result_view = findViewById(R.id.temp_result_val);

                try {
                    input_Val = Double.parseDouble(start_string.getText().toString());
                } catch (NumberFormatException exc) {
                    result_view.setText(String.valueOf(0));
                }

                if (starting_temperature) {
                    choice = 0;
                } else {
                    choice = 1;
                }

                if (result_temperature != starting_temperature) {
                    try {
                        input_Val = Double.parseDouble(start_string.getText().toString());
                    } catch (NumberFormatException exc) {
                        result_view.setText(String.valueOf(0));
                    }

                    converted_val = temperature_converter_wrapper(choice, input_Val);
                    result_view.setText(String.valueOf(Round(converted_val, 2)));
                } else {
                    result_view.setText(String.valueOf(input_Val));
                }
            }

        });
    }

    public void onItemSelected(AdapterView<?> parent, View view, int pos, long id) {
        switch (parent.getId()){
            case R.id.temp_starting_spinner:
                switch (pos) {
                    case 0:
                        starting_temperature = true;
                        break;
                    case 1:
                        starting_temperature = false;
                        break;
                    default:
                        break;
                }
                break;

            case R.id.temp_result_spinner:
                switch (pos) {
                    case 0:
                        result_temperature = true;
                        break;
                    case 1:
                        result_temperature = false;
                        break;
                    default:
                        break;
                }
                break;
        }

    }


    public void onNothingSelected(AdapterView<?> parent){
    }



    private double temperature_converter_wrapper (int choice, double input_temp){
        if (choice == 0){
            return TemperatureConverter.fahrenheit_to_celsius(input_temp);
        }
        else {
            return TemperatureConverter.celsius_to_fahrenheit(input_temp);
        }
    }
}

