package com.example.collegebuddy;
//Created by Sam Rovenstine Spring 2019

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import android.app.Activity;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ExpandableListAdapter;
import android.widget.ExpandableListView;
import android.widget.ExpandableListView.OnChildClickListener;
import android.widget.Toast;

public class DrinkingGamesActivity extends AppCompatActivity {

    List<String> ChildList;
    Map<String, List<String>> ParentListItems;
    ExpandableListView expandablelistView;

    // Game names, expandable fields
    List<String> list = new ArrayList<String>();
    {
        list.add("Beer Die");
        list.add("Beer Pong");
        list.add("Flip Cup");
        list.add("Quarters");
        list.add("Purple");
        list.add("Beer Roulette");
        list.add("Fuck The Dealer");
        list.add("Presidents");
        list.add("Cards Against Humanity");
        list.add("Straight Face");
        list.add("Sip Sip Shot");
        list.add("Drunk Jenga");
    }

    // Expandable Rules for each game
    String[] BeerDie = {"Opposing players sit or stand at opposite ends and throw a die over a " +
            "certain height with the goal of either landing the die in their opponent's cup or having " +
            "the die hit the table and bounce over the scoring area to the floor. The defending team attempts " +
            "to catch the die one-handed after it hits the table, but before it touches a non-table surface. The game " +
            "typically consists of two two-player teams with each of the four players having a designated cup " +
            "on the table, but can also be played one-vs-one. If the score leads to one team with a ‘victory’ " +
            "rebuttal will ensue and the losing team will have a chance to redeem themselves by tossing again."};

    String[] BeerPong = {"Is a drinking game in which players throw a ping pong ball across a table with the intent" +
            " of landing the ball in a cup of beer n the other end. The game typically consists of opposing teams of two" +
            " or more players per side with 6 or 10 cups set up in a triangle formation on each side. Each team then " +
            "takes turns attempting to shoot ping pong balls into the opponent's cups. If a ball lands in a cup " +
            "(known as a 'make'), the contents of that cup are consumed by the other team and the cup is removed from " +
            "the table. The first team to eliminate all of the opponent's cups is the winner."};

    String[] FlipCup  = {"Team-based drinking game where players must, in turn, drain a plastic cup of beer and " +
            "then \"flip\" the cup so that it lands face-down on the table. Two teams of an equal number of players " +
            "stand on opposite sides of a table, facing one another. The players directly facing are opponents. In " +
            "front of each teammate is a disposable plastic cup filled with a set amount of beer. Generally, the first " +
            "line inside a disposable cup is used as a marker." };

    String[] Quarters = {"Is a drinking game which involves players bouncing an American quarter or similar-size " +
            "coin off a table in an attempt to have the quarter land in a certain place, usually into a shot glass " +
            "(or cup) on that table. Each round starts off with a glass filled with beer in the middle of the table " +
            "and two people on opposite ends of the table having a quarter and a glass. Each player shoots his or her" +
            " quarter at his/her glass until he makes it in, then the player passes the glass to the player to his left." +
            " If the player to his left still has a glass as well, the player taps that glass with his, and the player " +
            "who has been tapped must drink the glass of beer in the middle of the table, refill it, then make " +
            "the quarter into his or her glass before she gets tapped again, with play still going around the table." +
            " If a player makes his or her first shot, he or she can then choose to pass the glass to any player who" +
            " does not currently have a glass."};

    String[] Purple = {""};
    String[] BeerRoulette = {""};
    String[] FuckTheDealer = {""};
    String[] Presidents = {""};
    String[] CardsAgainstHumanity = {""};
    String[] StraightFace = {""};
    String[] SipSipShot = {""};
    String[] DrunkJenga = {""};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_drinking_games);

        ParentListItems = new LinkedHashMap<>();

        for ( String HoldItem : list) {
            if (HoldItem.equals("Beer Die")) {
                loadChild(BeerDie);}
            else if (HoldItem.equals("Beer Pong"))
                loadChild(BeerPong);
            else if (HoldItem.equals("Flip Cup"))
                loadChild(FlipCup);
            else if (HoldItem.equals("Quarters"))
                loadChild(Quarters);
            else if (HoldItem.equals("Purple"))
                loadChild(Purple);
            else if (HoldItem.equals("BeerRoulette"))
                loadChild(BeerRoulette);
            else if (HoldItem.equals("Fuck The Dealer"))
                loadChild(FuckTheDealer);
            else if (HoldItem.equals("Presidents"))
                loadChild(Presidents);
            else if (HoldItem.equals("Cards Against Humanity"))
                loadChild(CardsAgainstHumanity);
            else if (HoldItem.equals("Straight Face"))
                loadChild(StraightFace);
            else if (HoldItem.equals("Sip Sip Shot"))
                loadChild(SipSipShot);
            else
                loadChild(DrunkJenga);
            ParentListItems.put(HoldItem, ChildList);
        }

        expandablelistView = findViewById(R.id.expandableListView1);
        final ExpandableListAdapter expListAdapter = new ListAdapter(
                this, list, ParentListItems);
        expandablelistView.setAdapter(expListAdapter);

        expandablelistView.setOnChildClickListener(new OnChildClickListener() {

            @Override
            public boolean onChildClick(ExpandableListView parent, View v,
                                        int groupPosition, int childPosition, long id) {
                final String selected = (String) expListAdapter.getChild(
                        groupPosition, childPosition);
                Toast.makeText(getBaseContext(), selected, Toast.LENGTH_LONG)
                        .show();

                return true;
            }
        });
    }

    private void loadChild(String[] ParentElementsName) {
        ChildList = new ArrayList<String>();
        for (String model : ParentElementsName)
            ChildList.add(model);
    }

}




/*
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;

public class DrinkingGamesActivity extends AppCompatActivity {

    ListView listView;
    List list = new ArrayList();
    ArrayAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_drinking_games);

        listView = findViewById(R.id.list_view);

        list.add("Beer Die");
        list.add("Beer Pong");
        list.add("Flip Cup");
        list.add("Quarters");
        list.add("Purple");
        list.add("Beer Roulette");
        list.add("Fuck The Dealer");
        list.add("Presidents");
        list.add("Cards Against Humanity");
        list.add("Straight Face");
        list.add("Sip Sip Shot");
        list.add("Drunk Jenga");


        adapter = new ArrayAdapter(DrinkingGamesActivity.this, android.R.layout.simple_list_item_1,list);
        listView.setAdapter(adapter);
    }
}
/*
        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
@Override
public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        Object listItem = list.getItemAtPosition(position);
        }
        });
        */