package com.example.collegebuddy;
//Created by Sam Rovenstine Spring 2019

import android.support.v7.app.AppCompatActivity;

public class PartyActivity extends AppCompatActivity {

}
