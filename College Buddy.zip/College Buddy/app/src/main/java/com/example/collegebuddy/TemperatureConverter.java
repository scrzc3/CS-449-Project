package com.example.collegebuddy;
//Created by Sam Rovenstine Spring 2019


public class TemperatureConverter {
    public static double fahrenheit_to_celsius(double fahrenheit){
        return((fahrenheit - 32.0)*(5.0/9.0));
    }
    public static double celsius_to_fahrenheit(double celsius){
        return(celsius * (9.0/5.0)) +32.0;
    }

}
