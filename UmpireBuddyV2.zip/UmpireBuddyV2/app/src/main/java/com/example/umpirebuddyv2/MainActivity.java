package com.example.umpirebuddyv2;
/*Created by Sam Rovenstine Spring 2019*/

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Build;
import android.preference.PreferenceManager;
import android.speech.tts.TextToSpeech;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.TextView;
import android.view.View;
import android.widget.Toast;
import android.support.v7.view.ActionMode;
import java.util.Locale;


public class MainActivity extends AppCompatActivity implements TextToSpeech.OnInitListener{

    private int mOutsCount, mBallsCount, mStrikesCount, mTotalOutsCount;
    private static String Out_Index = "out_index";
    private static String Ball_Index = "ball_index";
    private static String Strike_Index = "strike_index";
    private static String TotalOuts_Index = "totalouts_index";

    private ActionMode mActionMode;

    private TextToSpeech mTextToSpeech;
    private static final String TAG = "Umpire Buddy V2";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Button mBallsButton;
        Button mStrikesButton;

        setContentView(R.layout.activity_main);

        if (savedInstanceState != null) {
            mStrikesCount = savedInstanceState.getInt(Strike_Index);
            mBallsCount = savedInstanceState.getInt(Ball_Index);
            mOutsCount = savedInstanceState.getInt(Out_Index);
            mTotalOutsCount = savedInstanceState.getInt(TotalOuts_Index);

            TextView Strikeid = findViewById(R.id.strikesCount);
            TextView Ballid = findViewById(R.id.ballsCount);
            TextView Outid = findViewById(R.id.outsCount);
            TextView TotalOutsid = findViewById(R.id.TotalOutsCount);

            Strikeid.setText(String.valueOf(mStrikesCount));
            Ballid.setText(String.valueOf(mBallsCount));
            Outid.setText(String.valueOf(mOutsCount));
            TotalOutsid.setText(String.valueOf(mTotalOutsCount));

        }

        mTextToSpeech = new TextToSpeech(this, this);

        mBallsButton = findViewById(R.id.ballButton);
        mBallsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                BallCount(0);
                if (mBallsCount >= 4) {
                    AlertWalkDialog();
                    StrikeCount(1);
                    BallCount(1);
                    TotalOutsCount(1);
                }
            }
        });

        mStrikesButton = findViewById(R.id.strike_button);
        mStrikesButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                StrikeCount(0);
                if (mStrikesCount >= 3) {
                    AlertOutDialog();
                    StrikeCount(1);
                    BallCount(1);
                    OutCount(0);
                    TotalOutsCount(0);
                }
            }
        });

    //Context Menu
        TextView textView = findViewById(R.id.textView);
        textView.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                if (mActionMode != null) {
                    return false;
                }
                mActionMode = startSupportActionMode(mActionModeCallback);
                return true;
            }
        });
    }
    private ActionMode.Callback mActionModeCallback = new ActionMode.Callback() {
        @Override
        public boolean onCreateActionMode(ActionMode mode, Menu menu) {
            mode.getMenuInflater().inflate(R.menu.contextual_menu, menu);
            mode.setTitle("Choose your option");
            return true;
        }

        @Override
        public boolean onPrepareActionMode(ActionMode mode, Menu menu) {
            return false;
        }

        @Override
        public boolean onActionItemClicked(ActionMode mode, MenuItem item) {
            switch (item.getItemId()) {
                case R.id.option_1:
                    Toast.makeText(MainActivity.this, "Strike", Toast.LENGTH_SHORT).show();

                    {
                        mStrikesCount++;
                    }
                    if (mStrikesCount == 3){
                        mStrikesCount = 0;
                        mOutsCount++;
                        mTotalOutsCount++;
                        mBallsCount = 0;

                    }
                    if (mOutsCount == 3){
                    mOutsCount = 0;
                     }
                    if (mBallsCount == 4){
                        mBallsCount = 0;
                    }


                    TextView Strikeid = findViewById(R.id.ballsCount);
                    Strikeid.setText(String.valueOf(mBallsCount));

                    TextView Ballid = findViewById(R.id.strikesCount);
                    Ballid.setText(String.valueOf(mStrikesCount));

                    TextView TotalOutsid = findViewById(R.id.TotalOutsCount);
                    TotalOutsid.setText(String.valueOf(mTotalOutsCount));

                    TextView OutsId = findViewById(R.id.outsCount);
                    OutsId.setText(String.valueOf(mOutsCount));

                    mode.finish();
                    return true;

                    case R.id.option_2:
                    Toast.makeText(MainActivity.this, "Ball", Toast.LENGTH_SHORT).show();
                    {
                        mBallsCount++;
                    }
                    if (mBallsCount == 4){
                        mStrikesCount = 0;
                        mBallsCount = 0;

                    }

                    TextView Strike = findViewById(R.id.ballsCount);
                    Strike.setText(String.valueOf(mBallsCount));

                    TextView Ball = findViewById(R.id.strikesCount);
                    Ball.setText(String.valueOf(mStrikesCount));

                    mode.finish();

                    return true;
                default:
                    return false;
            }
        }

        @Override
        public void onDestroyActionMode(ActionMode mode) {
            mActionMode = null;
        }
    };



    //Dialog boxes that appear after each Strike/Ball limit is reached before resetting to new hitter
    private void AlertOutDialog() {

        say(getString(R.string.alert_title) + "Out");
        AlertDialog.Builder OutDialog = new AlertDialog.Builder(MainActivity.this);
        OutDialog.setMessage("Out");
        OutDialog.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                // User clicks OK
            }
        })
        .show();
    }

    private void AlertWalkDialog() {

        say("Walk" + getString(R.string.alert_title_2) );
        AlertDialog.Builder WalkDialog = new AlertDialog.Builder(MainActivity.this);
        WalkDialog.setMessage("Walk");
        WalkDialog.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                // User clicks OK
            }
        })
        .show();
    }

    private void say(String message) {
        boolean announce = PreferenceManager.getDefaultSharedPreferences(this)
                .getBoolean(this.getString(R.string.preference_announce_key), false);
        if (announce) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                mTextToSpeech.speak(message, TextToSpeech.QUEUE_FLUSH, null, null);
            } else {
                mTextToSpeech.speak(message, TextToSpeech.QUEUE_FLUSH, null);
            }
        }
    }



    //Equations/Parameters for when a player is out and/or gets a walk
    public void StrikeCount(int val) {
        if (val == 0)
        {
            mStrikesCount++;
        }
        else{
            mStrikesCount = 0;
        }
        TextView Ballid = findViewById(R.id.strikesCount);
        Ballid.setText(String.valueOf(mStrikesCount));
    }

    public void OutCount(int val) {
        if (val == 0) {
            mOutsCount++;
        }

        if (mOutsCount == 3){
            mOutsCount = 0;
        }
        TextView OutsId = findViewById(R.id.outsCount);
        OutsId.setText(String.valueOf(mOutsCount));
    }

    public void BallCount(int val) {
        if (val == 0)
        {
            mBallsCount++;
        }
        else{
            mBallsCount = 0;
        }
        TextView Strikeid = findViewById(R.id.ballsCount);
        Strikeid.setText(String.valueOf(mBallsCount));
    }

    public void TotalOutsCount(int val) {
        if (val == 0) {
            mTotalOutsCount++;
        }
        TextView TotalOutsid = findViewById(R.id.TotalOutsCount);
        TotalOutsid.setText(String.valueOf(mTotalOutsCount));
    }
    @Override
    public void onSaveInstanceState(Bundle savedInstanceState) {
        super.onSaveInstanceState(savedInstanceState);
        savedInstanceState.putInt(Ball_Index, mBallsCount);
        savedInstanceState.putInt(Strike_Index, mStrikesCount);
        savedInstanceState.putInt(Out_Index, mOutsCount);
        savedInstanceState.putInt(TotalOuts_Index, mTotalOutsCount);
    }
    @Override
    public void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onSaveInstanceState(savedInstanceState);
        savedInstanceState.putInt(Ball_Index, mBallsCount);
        savedInstanceState.putInt(Strike_Index, mStrikesCount);
        savedInstanceState.putInt(Out_Index, mOutsCount);
        savedInstanceState.putInt(TotalOuts_Index, mTotalOutsCount);
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.menu_reset:
                reset();
                return true;
            case R.id.menu_about:
                Intent about = new Intent(MainActivity.this, AboutActivity.class);
                startActivity(about);
                return true;
            case R.id.menu_settings:
                Intent settings = new Intent(MainActivity.this, SettingsActivity.class);
                startActivity(settings);
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }


    private void reset() {
        mStrikesCount = 0;
        mBallsCount = 0;
        mOutsCount = 0;

        TextView Strikeid = findViewById(R.id.ballsCount);
        Strikeid.setText(String.valueOf(mBallsCount));

        TextView Ballid = findViewById(R.id.strikesCount);
        Ballid.setText(String.valueOf(mStrikesCount));

        TextView TotalOutsid = findViewById(R.id.TotalOutsCount);
        TotalOutsid.setText(String.valueOf(mTotalOutsCount));

        TextView OutsId = findViewById(R.id.outsCount);
        OutsId.setText(String.valueOf(mOutsCount));
    }


    @Override
    public void onInit(int status) {
        if (status != TextToSpeech.SUCCESS) {
            Log.e(TAG, "Could not initialize TextToSpeech.");
            return;
        }

        int result = mTextToSpeech.setLanguage(Locale.US);
        if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
            Log.e(TAG, "Language is not available.");
        }
    }


}